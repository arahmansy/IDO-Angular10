import { Component, OnInit,Inject } from '@angular/core';
import { TodoServiceService } from 'src/app/services/todo-service.service';
import { FormBuilder} from '@angular/forms';
import { Validators } from '@angular/forms';
import { TodoItem } from 'src/app/models/todo-item.model';
import { MatDialogRef } from '@angular/material/dialog';
import {MAT_DIALOG_DATA} from '@angular/material/dialog';





@Component({
  selector: 'app-todo-item-form',
  templateUrl: './todo-item-form.component.html',
  styleUrls: ['./todo-item-form.component.css'
  ]
})
export class TodoItemFormComponent implements OnInit {

  constructor(public service :TodoServiceService, private fb : FormBuilder ,
    public matdiagref : MatDialogRef<TodoItemFormComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {name: string}) {}



  ToDoItemForm = this.fb.group({
    itemId:0,
    itemName: ['', [Validators.required]],
    itemStatus: ['todo'],
    itemCategory:'',
    itemImportance:'',
    itemDueDate:'',
    itemEstimate:''});

  ngOnInit(): void {
    this.service.refreshList();
    
    //console.log(this.service.list);
  }

  test()
  {

      console.log( this.data.name);

      this.ToDoItemForm.patchValue({itemName:this.data.name ,itemId:0});
     
  }


  listall()
  {
    this.service.refreshList();
    console.log(this.service.list);
  }
  onsubmit()
  {
    //this.service.todoData=this.ToDoItemForm.value;
    //console.log(this.ToDoItemForm.value);
    this.service.postToDoListItem(this.ToDoItemForm.value).subscribe(data =>{console.log(data)},err =>{console.error(err)});
    this.matdiagref.close();
  }
  sendForm()
  {

  }

  initializeForm()
  {
    this.ToDoItemForm.reset();
  }
}
