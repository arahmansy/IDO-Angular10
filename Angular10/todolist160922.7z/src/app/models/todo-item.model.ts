 
export class TodoItem {
    itemID: number=0;
    itemName: string='';
    itemDescription: string='';
    itemStatus: string="todo";
    itemCategory:string='';
    itemImportance : String='';
    itemDueDate :string='';
    itemEstimate : String='';
}