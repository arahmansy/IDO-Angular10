import { Routes } from '@angular/router'

import { AppComponent } from './app.component'
import { TodoItemsComponent } from './todo-items/todo-items.component'
import { TodoItemFormComponent } from './todo-items/todo-item-form/todo-item-form.component'

import { LoginComponent } from './login/login.component'

export const appRoutes: Routes = [
    { path: 'home', component: AppComponent },
    ,
    {
        path: 'login', component: LoginComponent
    },
    { path : '', redirectTo:'/login', pathMatch : 'full'}

];