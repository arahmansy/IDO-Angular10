import { Component, OnInit } from '@angular/core';
import { AuthServiceService } from '../services/auth-service.service';
import { FormControl,Validator,FormBuilder,FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { Route } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: [
  ]
})
export class LoginComponent implements OnInit {

  responsdata : any;

  loginForm = new FormGroup(
    {
     // userid : new FormControl(0),
       username : new FormControl("",[Validators.required,Validators.email]),
       password: new FormControl("",Validators.required)
    }
  )
   
  constructor( private service :AuthServiceService , private route : Router) { }

  ngOnInit(): void {
  }

  _login()
  {
    if(this.loginForm.valid)
    {
        this.service.login(this.loginForm.value).subscribe(result => {
          if(result!=null)
          {
            this.responsdata=result;
            localStorage.setItem("token",this.responsdata.jwttoken);
            this.route.navigate(['']);
          }
        })
    }
    else
    {

    }

  }

}
