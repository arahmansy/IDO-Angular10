import { Auth.Interceptor } from './auth.interceptor';

describe('Auth.Interceptor', () => {
  it('should create an instance', () => {
    expect(new Auth.Interceptor()).toBeTruthy();
  });
});
