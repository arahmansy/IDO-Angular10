import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders ,HttpClientModule } from '@angular/common/http';
import { TodoItem } from '../models/todo-item.model';
import { Login } from '../models/login.model';


@Injectable({
  providedIn: 'root'
})
export class TodoServiceService {


  readonly baseURL = "http://localhost:5000/api/Todolists";
 // readonly authURL = "http://localhost:24288/api/Authentication";
  list: TodoItem[]=[];


  constructor( private http :HttpClient) { }

  todoData: TodoItem = new TodoItem();
  loginData: Login = new Login();
  
  postToDoListItem(data:TodoItem) {
    console.log("Service side");
    console.log(data);
    return this.http.post(this.baseURL, data);
  }

  putToDoItem(id:string , data:TodoItem) {
    return this.http.put(`${this.baseURL}/${id}`, data);
  }

  deleteTodoItem(id: number) {
    return this.http.delete(`${this.baseURL}/${id}`);
  }
  

  refreshList() {
    this.http.get(this.baseURL)
      .toPromise()
      .then(res =>this.list = res as TodoItem[]);
  }

}
